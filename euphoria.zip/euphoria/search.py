import os
import csv
import pyfiglet
import xlrd
from openpyxl import load_workbook
from colorama import init, Fore, Style
from pystyle import *
import random
import time              
import requests
from fake_useragent import UserAgent
import subprocess
from colorama import Fore, Style
import colorama

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

print(Colorate.Horizontal(Colors.red_to_blue, (""" 
                                     



                                                       ██████ ▓█████ ▄▄▄       ██▀███   ▄████▄   ██░ ██ 
                                                     ▒██    ▒ ▓█   ▀▒████▄    ▓██ ▒ ██▒▒██▀ ▀█  ▓██░ ██▒
                                                     ░ ▓██▄   ▒███  ▒██  ▀█▄  ▓██ ░▄█ ▒▒▓█    ▄ ▒██▀▀██░
                                                       ▒   ██▒▒▓█  ▄░██▄▄▄▄██ ▒██▀▀█▄  ▒▓▓▄ ▄██▒░▓█ ░██ 
                                                     ▒██████▒▒░▒████▒▓█   ▓██▒░██▓ ▒██▒▒ ▓███▀ ░░▓█▒░██▓
                                                     ▒ ▒▓▒ ▒ ░░░ ▒░ ░▒▒   ▓▒█░░ ▒▓ ░▒▓░░ ░▒ ▒  ░ ▒ ░░▒░▒
                                                     ░ ░▒  ░ ░ ░ ░  ░ ▒   ▒▒ ░  ░▒ ░ ▒░  ░  ▒    ▒ ░▒░ ░
                                                     ░  ░  ░     ░    ░   ▒     ░░   ░ ░         ░  ░░ ░
                                                           ░     ░  ░     ░  ░   ░     ░ ░       ░  ░  ░
                                                                                             ░                


                                                        ⌈─────────────────────|─────────────────────────⌉
                                                        │tgc: @xwondedperehod |creator: @asphyxia_panic │
                                                        ⌊─────────────────────|─────────────────────────⌋                   
                                                              |  tgc with bd: @asphyxia_bio |
                                                              ⌊─────────────────────────────⌋
                                                              ┌─────────────────────────────┐    
                                                              │[1]     universal search     │
                                                              │-----------------------------│    
                                                              │[2]    search by nickname    │    
                                                              │-----------------------------│    
                                                              │[3]  search by IP address    │   
                                                              │-----------------------------│      
                                                              │[4]  geolocation by number   │   
                                                              │-----------------------------│      
                                                              │[5]  search by mac address   │   
                                                              └─────────────────────────────┘    
    """))) 

    

    
choice = input(Fore.RED + "                                            Выберите номер функции ('q' для выхода в меню) : " + Style.RESET_ALL)

if choice.lower() == "q":
    os.system("python main.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "1":
    os.system("python uni.py")  # Замените 'file1.py' на имя вашего файла


if choice.lower() == "2":


    user = input(Colorate.Horizontal(Colors.red_to_blue, ("Введите ник:").strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, ("Проверьте эти ссылки").strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" телеграмм: https://t.me/" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" вконтакте: https://vk.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" oдноклассники: https://ok.ru/" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" github: https://github.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" яндекc: https://yandex.ru/search/?text=" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" инстаграм: https://www.instagram.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" тикток: https://www.tiktok.com/@" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" твиттер: https://twitter.com/" + user).strip())) 
    print(Colorate.Horizontal(Colors.red_to_blue, (" фейсбук: https://www.facebook.com/" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" ютуб: https://www.youtube.com/@" + user).strip()))
    print(Colorate.Horizontal(Colors.red_to_blue, (" роблокс: https://www.roblox.com/user.aspx?username=" + user).strip()))
    input("")
    
if choice.lower() == "3":
    os.system("python searchip.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "4":
    os.system("python geo.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "5":
    os.system("python mac.py")  # Замените 'file1.py' на имя вашего файла