import os
import csv
import pyfiglet
import xlrd
from openpyxl import load_workbook
from colorama import init, Fore, Style
from pystyle import *
import random
import time              
import requests
from fake_useragent import UserAgent
import subprocess
from colorama import Fore, Style
import colorama

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

print(Colorate.Horizontal(Colors.red_to_blue, (""" 
                                     


                                     
                                              ▓█████  █    ██  ██▓███   ██░ ██  ▒█████   ██▀███   ██▓ ▄▄▄      
                                              ▓█   ▀  ██  ▓██▒▓██░  ██▒▓██░ ██▒▒██▒  ██▒▓██ ▒ ██▒▓██▒▒████▄    
                                              ▒███   ▓██  ▒██░▓██░ ██▓▒▒██▀▀██░▒██░  ██▒▓██ ░▄█ ▒▒██▒▒██  ▀█▄  
                                              ▒▓█  ▄ ▓▓█  ░██░▒██▄█▓▒ ▒░▓█ ░██ ▒██   ██░▒██▀▀█▄  ░██░░██▄▄▄▄██ 
                                              ░▒████▒▒▒█████▓ ▒██▒ ░  ░░▓█▒░██▓░ ████▓▒░░██▓ ▒██▒░██░ ▓█   ▓██▒
                                              ░░ ▒░ ░░▒▓▒ ▒ ▒ ▒▓▒░ ░  ░ ▒ ░░▒░▒░ ▒░▒░▒░ ░ ▒▓ ░▒▓░░▓   ▒▒   ▓▒█░
                                               ░ ░  ░░░▒░ ░ ░ ░▒ ░      ▒ ░▒░ ░  ░ ▒ ▒░   ░▒ ░ ▒░ ▒ ░  ▒   ▒▒ ░
                                                 ░    ░░░ ░ ░ ░░        ░  ░░ ░░ ░ ░ ▒    ░░   ░  ▒ ░  ░   ▒   
                                                 ░  ░   ░               ░  ░  ░    ░ ░     ░      ░        ░  ░
                                                                 

                                                      ⌈─────────────────────|─────────────────────────⌉
                                                      │tgc: @xwondedperehod |creator: @asphyxia_panic │
                                                      ⌊─────────────────────|─────────────────────────⌋                   

                                                              ┌─────────────────────────────┐    
                                                              │[1]          searh           │
                                                              │-----------------------------│ 
                                                              │[2]   demolition \ fishing   │
                                                              │-----------------------------│        
                                                              │[3]    network protocols     │
                                                              │-----------------------------│        
                                                              │[4]       generators         │
                                                              └─────────────────────────────┘ 
    """))) 

    

    
choice = input(Fore.RED + "                                            Выберите номер функции или что то другое для выхода : " + Style.RESET_ALL)

# Проверка введенного выбора и открытие файла
if choice.lower() == "1":
    os.system("python search.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "2":
    os.system("python dem.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "3":
    os.system("python net.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "4":
    os.system("python gen.py")  # Замените 'file1.py' на имя вашего файла

else:
    print(Fore.YELLOW + "неверный выбор" + Style.RESET_ALL)