import os
import csv
import pyfiglet
import xlrd
from openpyxl import load_workbook
from colorama import init, Fore, Style
from pystyle import *
import random
import time              
import requests
from fake_useragent import UserAgent
import subprocess
from colorama import Fore, Style
import colorama

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

print(Colorate.Horizontal(Colors.red_to_blue, (""" 
                                     




                                       ▓█████▄ ▓█████  ███▄ ▄███▓ ▒█████   ██▓     ██▓▄▄▄█████▓ ██▓ ▒█████   ███▄    █ 
                                       ▒██▀ ██▌▓█   ▀ ▓██▒▀█▀ ██▒▒██▒  ██▒▓██▒    ▓██▒▓  ██▒ ▓▒▓██▒▒██▒  ██▒ ██ ▀█   █ 
                                       ░██   █▌▒███   ▓██    ▓██░▒██░  ██▒▒██░    ▒██▒▒ ▓██░ ▒░▒██▒▒██░  ██▒▓██  ▀█ ██▒
                                       ░▓█▄   ▌▒▓█  ▄ ▒██    ▒██ ▒██   ██░▒██░    ░██░░ ▓██▓ ░ ░██░▒██   ██░▓██▒  ▐▌██▒
                                       ░▒████▓ ░▒████▒▒██▒   ░██▒░ ████▓▒░░██████▒░██░  ▒██▒ ░ ░██░░ ████▓▒░▒██░   ▓██░
                                        ▒▒▓  ▒ ░░ ▒░ ░░ ▒░   ░  ░░ ▒░▒░▒░ ░ ▒░▓  ░░▓    ▒ ░░   ░▓  ░ ▒░▒░▒░ ░ ▒░   ▒ ▒ 
                                        ░ ▒  ▒  ░ ░  ░░  ░      ░  ░ ▒ ▒░ ░ ░ ▒  ░ ▒ ░    ░     ▒ ░  ░ ▒ ▒░ ░ ░░   ░ ▒░
                                        ░ ░  ░    ░   ░      ░   ░ ░ ░ ▒    ░ ░    ▒ ░  ░       ▒ ░░ ░ ░ ▒     ░   ░ ░ 
                                          ░       ░  ░       ░       ░ ░      ░  ░ ░            ░      ░ ░           ░ 
                                        ░                                                                              


                                                        ⌈─────────────────────|─────────────────────────⌉
                                                        │tgc: @xwondedperehod |creator: @asphyxia_panic │
                                                        ⌊─────────────────────|─────────────────────────⌋                   

                                                              ┌─────────────────────────────┐    
                                                              │[1]   demolition tg session  │    
                                                              │-----------------------------│    
                                                              │[2]    demolition tg|tgc     │    
                                                              └─────────────────────────────┘    
    """))) 

    

    
choice = input(Fore.RED + "                                            Выберите номер функции ('q' для выхода в меню) : " + Style.RESET_ALL)

if choice.lower() == "q":
    os.system("python main.py")  # Замените 'file1.py' на имя вашего файла
    
if choice.lower() == "1":
    os.system("python session.py")  # Замените 'file1.py' на имя вашего файла

if choice.lower() == "2":
    os.system("python snos.py")  # Замените 'file1.py' на имя вашего файла